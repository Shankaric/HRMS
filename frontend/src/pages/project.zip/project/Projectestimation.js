import React, { useState, useEffect, useRef } from "react";
import {
    Box, Typography, OutlinedInput, TableRow,TableCell,FormControl,TableBody, Select,MenuItem,DialogContent, Grid, Dialog, DialogActions, Paper, Table, TableHead, TableContainer, Button,
} from "@mui/material";
import { userStyle } from "../../pageStyle";
import axios from "axios";
import { FaPrint, FaFilePdf } from "react-icons/fa";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import { ExportXL, ExportCSV } from "../../components/Export";
import {StyledTableRow, StyledTableCell} from "../../components/Table";
import { useReactToPrint } from "react-to-print";
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import jsPDF from "jspdf";
import 'jspdf-autotable';
// import Headtitle from "../../components/header/Headtitle";
import $ from "jquery";
// import { UserRoleAccessContext } from "../../context/Appcontext";
import { SERVICE } from "../../services/Baseservice";
import ArrowDropUpOutlinedIcon from '@mui/icons-material/ArrowDropUpOutlined';
import ArrowDropDownOutlinedIcon from '@mui/icons-material/ArrowDropDownOutlined';
// import { AuthContext } from '../../context/Appcontext';
// import { useNavigate} from 'react-router-dom';


function ProjectEstimation() {
    // const { isUserRoleCompare } = useContext(UserRoleAccessContext);
    // const { auth, setAuth } = useContext(AuthContext);
    const [deletebranch, setDeletebranch] = useState(false);
    const [getrowid, setRowGetid] = useState("");
    const [projEstimateEdit, setProjEstimateEdit] = useState({});
    const [projEstimate, setProjEstimate] = useState({
        expectcompdate: "",
        expectcomptime: "",
        expectcompduration: "",
        budget: "",
        budgetsign: "",
        priority: "",
    });
    const [projEstlist, setProjEstList] = useState([]);
    const [project, setProject] = useState([]);
    const [subProject, setSubProject] = useState([]);
    const [module, setModule] = useState([]);
    const [submodule, setSubmodule] = useState([]);
    const [mainpage, setMainpage] = useState([]);
    const [subpage1, setSubpage1] = useState([]);
    const [subpage2, setSubpage2] = useState([]);

    //Datatable
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(1);

      // view model
   const [openview, setOpenview] = useState(false);
  
   const handleClickOpenview = () => {
     setOpenview(true);
   };
 
   const handleCloseview = () => {
     setOpenview(false);
   };


             //fetching Project for Dropdowns
             const fetchProjectDropdowns = async () => {
                try {
                    let projectDrop = await axios.get(SERVICE.PROJECT);
                    setProject(projectDrop.data.projEstlist);
                } catch (error) {
                    console.log(error.response.data);
                }
            };
             
                //fetching sub-Project Dropdowns
                   const fetchSubProjectDropdowns = async (projectName) => {
                    try {
                        let subPro = await axios.get(SERVICE.SUBPROJECT);
                        let subProDrop = subPro.data.subprojEstlist.filter((data) => {
                            console.log(projectName);
                            if (projectName ===  data.project)      
                                return data     
                          })
                          setSubProject(subProDrop);
                        
                    } catch (error) {
                        console.log(error.response.data);
                    }
                };
        
                 //fetching Module Dropdowns
               const fetchModuleDropdowns = async (subPro) => {
                try {
                    let dropModule = await axios.get(SERVICE.MODULE);
                    let modulelist = dropModule.data.modules.filter((data) => {
                        if (subPro === data.subproject) {  
                            return data  
                        } 
           
                      })
                    setModule(modulelist);
                } catch (error) {
                    console.log(error.response.data);
                }
            };
        
        
                    //fetching Sub-Modules Dropdowns
                   const fetchSubModuleDropdowns = async (modu) => {
                    try {
                        let drosubmod = await axios.get(SERVICE.SUBMODULE);
                        let submodulelist = drosubmod.data.submodules.filter((data) => {
                            console.log(modu);
                            if (modu === data.module){
                                console.log(modu);
                                return data  
                            }    
                           
                          })
                        setSubmodule(submodulelist);
                    } catch (error) {
                        console.log(error.response.data);
                    }
                };
        
                //fetching Main Page Dropdowns
               const fetchMainPageDropdowns = async (submod) => {
                try {
                    let mainPag = await axios.get(SERVICE.MAINPAGE);
                    let mainPagdrop= mainPag.data.mains.filter((data) => {
                        if (submod === data.submodule)      
                            return data     
                      })
                    setMainpage(mainPagdrop);
                } catch (error) {
                    console.log(error.response.data);
                }
            };
        
        
                 //fetching Sub-Page-1 Dropdowns
                const fetchSubPage1Dropdowns = async (mainPag) => {
                    try {
                            let subpag1 = await axios.get(SERVICE.SUBPAGETWO);
                            let subPag1Drop= subpag1.data.subpagesone.filter((data) => {
                                if (mainPag === data.mainpage)      
                                    return data     
                              })
                                setSubpage1(subPag1Drop);
                            } catch (error) {
                                console.log(error.response.data);
                            }
                        };
        
        
                 //fetching Sub-Page-2 Dropdowns
               const fetchSubPage2Dropdowns = async (subpg1) => {
                try {
                    let subpag2 = await axios.get(SERVICE.SUBPAGETWO);
                    let subPag1Drop= subpag2.data.subpagesone.filter((data) => {
                        if (subpg1 === data.name)      
                            return data     
                      })
        
                    setSubpage2(subPag1Drop);
                } catch (error) {
                    console.log(error.response.data);
                }
            };

     //submitting the forms
     const handleSubmit = (e) => {
        sendRequest();
    };

    //submitting the form
    const sendRequest = async () => {
        try {
            let req = await axios.post(
                SERVICE.PROJECTESTIMATION_CREATE,
                {
                    project: String(projEstimate.project),
                    subproject: String(projEstimate.subproject),
                    module: String(projEstimate.module),
                    submodule: String(projEstimate.submodule),
                    mainpage: String(projEstimate.mainpage),
                    subpage1: String(projEstimate.subpage1),
                    subpage2: String(projEstimate.subpage2),
                    expectcompdate: String(projEstimate.expectcompdate),
                    expectcomptime: String(projEstimate.expectcomptime),
                    expectcompduration: String(projEstimate.expectcompduration),
                    budget: String(projEstimate.budget),
                    budgetsign: String(projEstimate.budgetsign),
                    priority: String(projEstimate.priority),

                }
            );
            setProjEstimate(req.data);
            setProjEstimate({  expectcompdate: "",
            expectcomptime: "",
            expectcompduration: "",
            budget: "",
            budgetsign: "",
            priority: "", });


        } catch (error) {
            console.log(error.response.data.message);
        }
    };

    //fetching Project Estimation for list Page
    const fetchProjectEstList = async () => {
        try {
            let dep = await axios.get(SERVICE.PROJECTESTIMATION);

            setProjEstList(dep.data.projectestimation);
        } catch (error) {
            console.log(error.response.data);
        }
    };
  

    //get single row to edit
    const getCode = async (e) => {
        setRowGetid(e);
        let res = await axios.get(
            `${SERVICE.PROJECTESTIMATION_SINGLE}/${e}`,
            {}
        );

        setProjEstimateEdit(res.data.sprojectestimation);
        setRowGetid(res.data.sprojectestimation);
    };

     // get single row to view....
   const getviewCode = async (e) => {
    let res = await axios.get(`${SERVICE.PROJECTESTIMATION_SINGLE}/${e}`, {});
    setProjEstimateEdit(res.data.sprojectestimation);
  };

    //editing the single data

    let lang_id = getrowid._id;
    const sendEditRequest = async () => {
        try {
            let res = await axios.put(
                `${SERVICE.PROJECTESTIMATION_SINGLE}/${lang_id}`,
                {
                    project: String(projEstimateEdit.project),
                    subproject: String(projEstimateEdit.subproject),
                    module: String(projEstimateEdit.module),
                    submodule: String(projEstimateEdit.submodule),
                    mainpage: String(projEstimateEdit.mainpage),
                    subpage1: String(projEstimateEdit.subpage1),
                    subpage2: String(projEstimateEdit.subpage2),
                    expectcompdate: String(projEstimateEdit.expectcompdate),
                    expectcomptime: String(projEstimateEdit.expectcomptime),
                    expectcompduration: String(projEstimateEdit.expectcompduration),
                    budget: String(projEstimateEdit.budget),
                    budgetsign: String(projEstimateEdit.budgetsign),
                    priority: String(projEstimateEdit.priority),

                }
            );
            setProjEstimateEdit(res.data);
            handleCloseModEdit();
        } catch (err) { 
            console.log(err.response.data.message)
        }
    };

    const editSubmit = (e) => {
        e.preventDefault();
        sendEditRequest();
    };

    //    PDF
    const columns = [
        { title: "Name", field: "qualiname" },
    ]
    const downloadPdf = () => {
        const doc = new jsPDF()
        doc.autoTable({
            theme: "grid",
            columns: columns.map(col => ({ ...col, dataKey: col.field })),
            body: projEstlist
        })
        doc.save('ProjectEstimation.pdf')
    }
 

    // Excel
    const fileName = "ProjectEstimation";
    let excelno=1;

    const [exceldata, setExceldata] = useState([]);

    // get perticular columns for export excel
    const getexcelDatas = async () => {

        let Dep = await axios.get(SERVICE.PROJECTESTIMATION)

        var data = Dep.data.projectestimation.map(t => ({
            SNo: excelno++,
            expectcompdate: t.expectcompdate,
                    expectcomptime: t.expectcomptime,
                    expectcompduration: t.expectcompduration,
                    budget: t.budget,
                    budgetsign: t.budgetsign,
                    priority: t.priority,

        }));
        setExceldata(data);
    }

    // Print
    const componentRef = useRef();
    const handleprint = useReactToPrint({
        content: () => componentRef.current,
        documentTitle: 'PROJECTESTIMATION',
        pageStyle: 'print'
    });

    // Delete model
    const [isDeleteOpen, setIsDeleteOpen] = useState(false);
    const handleClickOpen = () => {
        setIsDeleteOpen(true);
    };
    const handleCloseMod = () => {
        setIsDeleteOpen(false);
    };

    // Edit model
    const [isEditOpen, setIsEditOpen] = useState(false);
    const handleClickOpenEdit = () => {
        setIsEditOpen(true);
    };
    const handleCloseModEdit = (e, reason) => {
        if (reason && reason === "backdropClick") 
        return;
        setIsEditOpen(false);
    };
    
    //set function to get particular row to Delete
    const rowData = async (id) => {
        try {
            let res = await axios.get(
                `${SERVICE.PROJECTESTIMATION_SINGLE}/${id}`
            );
            setDeletebranch(res.data.sprojectestimation);
        } catch (err) { }
    };

    // Alert delete popup
    let branchid = deletebranch._id;
    const delBranch = async () => {
        try {
            await axios.delete( `${SERVICE.PROJECTESTIMATION_SINGLE}/${branchid}` );
            handleCloseMod();
        } catch (err) {
            console.log(err.response.data.errorMessage)
         }
    };

    

    useEffect(() => {
        fetchProjectEstList();
        getexcelDatas();
    });

    useEffect(() => {
        fetchProjectDropdowns();
        fetchSubProjectDropdowns();
       fetchModuleDropdowns();
        fetchSubModuleDropdowns();
        fetchMainPageDropdowns();
         fetchSubPage1Dropdowns();
         fetchSubPage2Dropdowns();
 
 
    },[]);

    const [items, setItems] = useState([]);

    const addSerialNumber = () => {
      const itemsWithSerialNumber = projEstlist?.map((item, index) => ({ ...item, serialNumber: index + 1 }));
      setItems(itemsWithSerialNumber);
    }
  
    useEffect(()=>{
      addSerialNumber();
    })
  
      //table sorting
      const [sorting, setSorting] = useState({ column: '', direction: '' });
  
      const handleSorting = (column) => {
          const direction = sorting.column === column && sorting.direction === 'asc' ? 'desc' : 'asc';
          setSorting({ column, direction });
      };
  
      const sortedData = items.sort((a, b) => {
          if (sorting.direction === 'asc') {
              return a[sorting.column] > b[sorting.column] ? 1 : -1;
          } else if (sorting.direction === 'desc') {
              return a[sorting.column] < b[sorting.column] ? 1 : -1;
          }
          return 0;
      });
  
      const renderSortingIcon = (column) => {
          if (sorting.column !== column) {
              return <>
                  <Box sx={{ color:'#bbb6b6'}}>
                      <Grid sx={{height:'6px',fontSize:'1.6rem'}}>
                          <ArrowDropUpOutlinedIcon/>
                      </Grid>
                      <Grid sx={{height:'6px',fontSize:'1.6rem'}}>
                          <ArrowDropDownOutlinedIcon/>
                      </Grid>
                  </Box>
              </>;
          } else if (sorting.direction === 'asc') {
              return <>
                  <Box >
                      <Grid sx={{height:'6px'}}>
                          <ArrowDropUpOutlinedIcon style={{ color:'black',fontSize:'1.6rem'}}/>
                      </Grid>
                      <Grid sx={{height:'6px'}}>
                          <ArrowDropDownOutlinedIcon style={{ color:'#bbb6b6',fontSize:'1.6rem'}}/>
                      </Grid>
                  </Box>
              </>;
          } else {
              return  <>
                  <Box >
                      <Grid sx={{height:'6px'}}>
                          <ArrowDropUpOutlinedIcon style={{ color:'#bbb6b6',fontSize:'1.6rem'}}/>
                      </Grid>
                      <Grid sx={{height:'6px'}}>
                          <ArrowDropDownOutlinedIcon style={{ color:'black',fontSize:'1.6rem'}}/>
                      </Grid>
                  </Box>
              </>;
          }
      };
  //Datatable
    const handlePageChange = (newPage) => {
      setPage(newPage);
    };
  
    const handlePageSizeChange = (event) => {
      setPageSize(Number(event.target.value));
      setPage(1);
    };
  
   
      
    //datatable....
    const [searchQuery, setSearchQuery] = useState("");
    const handleSearchChange = (event) => {
      setSearchQuery(event.target.value);
    };
    const filteredDatas = items.filter((item) =>
      Object.values(item).some((value) =>
        value.toString().toLowerCase().includes(searchQuery.toLowerCase())
      )
    );
  
    const filteredData = filteredDatas.slice((page - 1) * pageSize, page * pageSize);
  
    const totalPages = Math.ceil(projEstlist.length / pageSize);
  
    const visiblePages = Math.min(totalPages, 3);
  
    const firstVisiblePage = Math.max(1, page - 1);
    const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPages);
  
    const pageNumbers = [];
  
    const indexOfLastItem = page * pageSize;
    const indexOfFirstItem = indexOfLastItem - pageSize;
  
    for (let i = firstVisiblePage; i <= lastVisiblePage; i++) {
      pageNumbers.push(i);
    }
  

    return (
        <Box>
            {/* <Headtitle title={"Qualification"} /> */}
            {/* ****** Header Content ****** */}
            <Typography sx={userStyle.HeaderText}>Project Estimation</Typography>

            <Box sx={userStyle.container}>
                <>
                <Grid container spacing={2}>
                        <Grid item md={6} sx={12}>
                            <Typography>Project</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimate.project}
                                            onChange={(e) => {
                                                setProjEstimate({ ...projEstimate, project: e.target.value });
                                                fetchSubProjectDropdowns (e.target.value);
                                            }}
                                        >
                                            {
                                                project && project.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                        <Grid item md={6} sx={12}>
                            <Typography>Sub-Project</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimate.subproject}
                                            onChange={(e) => {
                                                setProjEstimate({ ...projEstimate, subproject: e.target.value });
                                                fetchModuleDropdowns(e.target.value);
                                            }}
                                        >
                                                {
                                                subProject && subProject.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                       
                    </Grid><br/>
                    <Grid container spacing={2}>
                        <Grid item md={6} sx={12}>
                            <Typography>Module</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimate.module}
                                            onChange={(e) => {
                                                setProjEstimate({ ...projEstimate, module: e.target.value });
                                                fetchSubModuleDropdowns(e.target.value);
                                            }}
                                        >
                                                {
                                                module && module.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                        <Grid item md={6} sx={12}>
                            <Typography>Sub-Module</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimate.submodule}
                                            onChange={(e) => {
                                                setProjEstimate({ ...projEstimate, submodule: e.target.value });
                                                fetchMainPageDropdowns(e.target.value);
                                               
                                            }}
                                        >
                                                {
                                                submodule && submodule.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                       
                    </Grid><br/>
                    <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                            <Typography>Main Page</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimate.mainpage}
                                            onChange={(e) => {
                                                setProjEstimate({ ...projEstimate, mainpage: e.target.value });
                                                fetchSubPage1Dropdowns(e.target.value);
                                            }}
                                        >
                                                {
                                                mainpage && mainpage.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                        <Grid item md={4} sx={12}>
                            <Typography>Sub-Page 1</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimate.subpage1}
                                            onChange={(e) => {
                                                setProjEstimate({ ...projEstimate, subpage1: e.target.value });
                                                fetchSubPage2Dropdowns(e.target.value );
                                                
                                            }}
                                        >
                                                {
                                                subpage1 && subpage1.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                        <Grid item md={4} sx={12}>
                            <Typography>Sub-Page 2</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimate.subpage2}
                                            onChange={(e) => {
                                                setProjEstimate({ ...projEstimate, subpage2: e.target.value });
                                            }}
                                        >
                                                {
                                                subpage2 && subpage2.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                       
                    </Grid><br/>
                    <Grid container spacing={2}>
                        <Grid item md={3} sx={12}>
                            <Typography>Expected Completion</Typography>

                            <FormControl fullWidth size="small">
                                <OutlinedInput
                                    id="component-outlined"
                                    type="date"
                                    value={projEstimate.expectcompdate}
                                    onChange={(e) => {
                                        setProjEstimate({ ...projEstimate, expectcompdate: e.target.value });
                                    }}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item md={3} sx={12}>
                            <Typography>Expected Time</Typography>

                            <FormControl fullWidth size="small">
                            <OutlinedInput
                                    id="component-outlined"
                                    type="time"
                                    value={projEstimate.expectcomptime}
                                    onChange={(e) => {
                                        setProjEstimate({ ...projEstimate, expectcomptime: e.target.value });
                                    }}
                                />
                       
                            </FormControl>
                        </Grid>
                        <Grid item md={3} sx={12}>
                            <Typography>Expected Duration</Typography>

                            <FormControl fullWidth size="small">
                                <OutlinedInput
                                    id="component-outlined"
                                    type="text"
                                    value={projEstimate.expectcompduration}
                                    onChange={(e) => {
                                        setProjEstimate({ ...projEstimate, expectcompduration: e.target.value });
                                    }}
                                />
                            </FormControl>
                        </Grid>
                    </Grid><br/>

                    <Grid container spacing={2}>
                        <Grid item md={3} sx={12}>
                            <Typography>Budget</Typography>

                            <FormControl fullWidth size="small">
                                <OutlinedInput
                                    id="component-outlined"
                                    type="number"
                                    value={projEstimate.budget}
                                    onChange={(e) => {
                                        setProjEstimate({ ...projEstimate, budget: e.target.value });
                                    }}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item md={1} sx={12}>
                            <FormControl fullWidth size="small">
                                 <Typography>Budget</Typography>
                                     <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimate.budgetsign}
                                            onChange={(e) => {
                                                setProjEstimate({ ...projEstimate, budgetsign: e.target.value });
                                            }}
                                        >
                                            <MenuItem value ={"₹"}>₹</MenuItem>
                                            <MenuItem value={"$"}>$</MenuItem>
                                        </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                    <Grid container spacing={2}>
                        <Grid item md={3} sx={12}>
                            <Typography>priority</Typography>
                                <FormControl fullWidth size="small">
                                        <Select
                                                    labelId="demo-select-small"
                                                    id="demo-select-small"
                                                    value={projEstimate.priority}
                                                    onChange={(e) => {
                                                        setProjEstimate({ ...projEstimate, priority: e.target.value });
                                                    }}
                                                >
                                                    {

                                                    }
                                                    <MenuItem value ={"Priority 1"}>Priority 1</MenuItem>
                                                  
                                            </Select>
                                </FormControl>
                        </Grid>
                    </Grid>
                    <br/><br/>
                    <Grid item md={3} sx={12}>
                            <Button variant="contained" onClick={handleSubmit}>Create</Button>
                    </Grid>
                    
                    <br />
                    <br />
                </>

                <>
                    <Box>
                        {/* ALERT DIALOG */}
                        <Dialog
                            open={isEditOpen}
                            onClose={handleCloseModEdit}
                            aria-labelledby="alert-dialog-title"
                            aria-describedby="alert-dialog-description"
                        >
                            <Box sx={userStyle.container}>
                            <Typography sx={userStyle.SubHeaderText}> Edit Project Estimation </Typography>
                            <br/><br />
                            <>
                            <Grid container spacing={2}>
                        <Grid item md={6} sx={12}>
                            <Typography>Project</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimateEdit.project}
                                            onChange={(e) => {
                                                setProjEstimateEdit({ ...projEstimateEdit, project: e.target.value });
                                                fetchSubProjectDropdowns (e.target.value);
                                            }}
                                        >
                                            {
                                                project && project.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                        <Grid item md={6} sx={12}>
                            <Typography>Sub-Project</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimateEdit.subproject}
                                            onChange={(e) => {
                                                setProjEstimateEdit({ ...projEstimateEdit, subproject: e.target.value });
                                                fetchModuleDropdowns(e.target.value);
                                            }}
                                        >
                                                {
                                                subProject && subProject.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                       
                    </Grid><br/>
                    <Grid container spacing={2}>
                        <Grid item md={6} sx={12}>
                            <Typography>Module</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimateEdit.module}
                                            onChange={(e) => {
                                                setProjEstimateEdit({ ...projEstimateEdit, module: e.target.value });
                                                fetchSubModuleDropdowns(e.target.value);
                                            }}
                                        >
                                                {
                                                module && module.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                        <Grid item md={6} sx={12}>
                            <Typography>Sub-Module</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimateEdit.submodule}
                                            onChange={(e) => {
                                                setProjEstimateEdit({ ...projEstimateEdit, submodule: e.target.value });
                                                fetchMainPageDropdowns(e.target.value);
                                               
                                            }}
                                        >
                                                {
                                                submodule && submodule.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                       
                    </Grid><br/>
                    <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                            <Typography>Main Page</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimateEdit.mainpage}
                                            onChange={(e) => {
                                                setProjEstimateEdit({ ...projEstimateEdit, mainpage: e.target.value });
                                                fetchSubPage1Dropdowns(e.target.value);
                                            }}
                                        >
                                                {
                                                mainpage && mainpage.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                        <Grid item md={4} sx={12}>
                            <Typography>Sub-Page 1</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimateEdit.subpage1}
                                            onChange={(e) => {
                                                setProjEstimateEdit({ ...projEstimateEdit, subpage1: e.target.value });
                                                fetchSubPage2Dropdowns(e.target.value );
                                                
                                            }}
                                        >
                                                {
                                                subpage1 && subpage1.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                        <Grid item md={4} sx={12}>
                            <Typography>Sub-Page 2</Typography>

                            <FormControl fullWidth size="small">
                            <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimateEdit.subpage2}
                                            onChange={(e) => {
                                                setProjEstimateEdit({ ...projEstimateEdit, subpage2: e.target.value });
                                            }}
                                        >
                                                {
                                                subpage2 && subpage2.map((data)=>{
                                                    return  <MenuItem value ={data.name}>{data.name}</MenuItem>
                                                })
                                            }
                                        </Select>
                            </FormControl>
                        </Grid>
                       
                    </Grid><br/>
                    <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                            <Typography>Expected Completion</Typography>

                            <FormControl fullWidth size="small">
                                <OutlinedInput
                                    id="component-outlined"
                                    type="date"
                                    value={projEstimateEdit.expectcompdate}
                                    onChange={(e) => {
                                        setProjEstimateEdit({ ...projEstimateEdit, expectcompdate: e.target.value });
                                    }}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item md={4} sx={12}>
                            <Typography>Expected Time</Typography>

                            <FormControl fullWidth size="small">
                            <OutlinedInput
                                    id="component-outlined"
                                    type="time"
                                    value={projEstimateEdit.expectcomptime}
                                    onChange={(e) => {
                                        setProjEstimateEdit({ ...projEstimateEdit, expectcomptime: e.target.value });
                                    }}
                                />
                       
                            </FormControl>
                        </Grid>
                        <Grid item md={4} sx={12}>
                            <Typography>Expected Duration</Typography>

                            <FormControl fullWidth size="small">
                                <OutlinedInput
                                    id="component-outlined"
                                    type="text"
                                    value={projEstimateEdit.expectcompduration}
                                    onChange={(e) => {
                                        setProjEstimateEdit({ ...projEstimateEdit, expectcompduration: e.target.value });
                                    }}
                                />
                            </FormControl>
                        </Grid>
                    </Grid><br/>

                    <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                            <Typography>Budget</Typography>

                            <FormControl fullWidth size="small">
                                <OutlinedInput
                                    id="component-outlined"
                                    type="number"
                                    value={projEstimateEdit.budget}
                                    onChange={(e) => {
                                        setProjEstimateEdit({ ...projEstimateEdit, budget: e.target.value });
                                    }}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item md={2} sx={12}>
                            <FormControl fullWidth size="small">
                                 <Typography>Budget</Typography>
                                     <Select
                                            labelId="demo-select-small"
                                            id="demo-select-small"
                                            value={projEstimateEdit.budgetsign}
                                            onChange={(e) => {
                                                setProjEstimateEdit({ ...projEstimateEdit, budgetsign: e.target.value });
                                            }}
                                        >
                                            <MenuItem value ={"₹"}>₹</MenuItem>
                                            <MenuItem value={"$"}>$</MenuItem>
                                        </Select>
                            </FormControl>
                        </Grid>
                    </Grid>
                    <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                            <Typography>priority</Typography>
                                <FormControl fullWidth size="small">
                                        <Select
                                                    labelId="demo-select-small"
                                                    id="demo-select-small"
                                                    value={projEstimateEdit.priority}
                                                    onChange={(e) => {
                                                        setProjEstimateEdit({ ...projEstimateEdit, priority: e.target.value });
                                                    }}
                                                >
                                                    {

                                                    }
                                                    <MenuItem value ={"Priority 1"}>Priority 1</MenuItem>
                                                  
                                            </Select>
                                </FormControl>
                        </Grid>
                    </Grid>
                    <br/><br/>
                </>
                                <br/><br />
                                <Grid container>
                                <Grid item md={1} sx={12}></Grid>
                                    <Grid item md={5} sx={12}>
                                        <Button variant="contained" onClick={editSubmit}> Update </Button>
                                    </Grid>
                                    <Grid item md={5} sx={12}>
                                        <Button sx={userStyle.btncancel} onClick={handleCloseModEdit}> cancel </Button>
                                    </Grid>
                                    <Grid item md={1} sx={12}></Grid>
                                </Grid>
                                
                            </Box>
                        </Dialog>
                    </Box>
                </>
            </Box>
            <br />
            {/* ****** Table Start ****** */}
            <>
                <Box sx={userStyle.container}>
                    { /* ****** Header Buttons ****** */}
                    <Grid container sx={{ justifyContent: "center" }} >
                        <Grid >
                            {/* {isUserRoleCompare[0].excelsupplier && (
                                <> */}
                            <ExportCSV csvData={exceldata} fileName={fileName} />
                            {/* </>
                            )} */}
                            {/* {isUserRoleCompare[0].csvsupplier && (
                                <> */}
                            <ExportXL csvData={exceldata} fileName={fileName} />
                            {/* </>
                            )} */}
                            {/* {isUserRoleCompare[0].printsupplier && (
                                <> */}
                            <Button sx={userStyle.buttongrp} onClick={handleprint}>&ensp;<FaPrint />&ensp;Print&ensp;</Button>
                            {/* </>
                            )} */}
                            {/* {isUserRoleCompare[0].pdfsupplier && (
                                <> */}
                            <Button sx={userStyle.buttongrp} onClick={() => downloadPdf()}><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                            {/* </>
                            )} */}
                        </Grid>
                    </Grid><br />
                 
                    { /* ******************************************************EXPORT Buttons****************************************************** */}
                    {/* ****** Table Grid Container ****** */}
                    <Grid style={userStyle.dataTablestyle}>
              <Box>
                <label htmlFor="pageSizeSelect">Show entries:</label>
                <Select id="pageSizeSelect" value={pageSize} onChange={handlePageSizeChange} sx={{width:"77px"}}>
                  <MenuItem value={1}>1</MenuItem>
                  <MenuItem value={5}>5</MenuItem>
                  <MenuItem value={10}>10</MenuItem>
                  <MenuItem value={25}>25</MenuItem>
                  <MenuItem value={50}>50</MenuItem>
                  <MenuItem value={100}>100</MenuItem>
                  <MenuItem value={(projEstlist.length)}>All</MenuItem>
                </Select>
              </Box>
              <Box>
                  <FormControl fullWidth size="small" >
                    <Typography>Search</Typography>
                    <OutlinedInput
                        id="component-outlined"
                        type="text"
                        value={searchQuery}
                        onChange={handleSearchChange}
                    />
                </FormControl>
            </Box>
            </Grid>

                    {/* ****** Table start ****** */}
                    <TableContainer component={Paper}>
                        <Table
                            sx={{ minWidth: 700, }}
                            aria-label="customized table"
                            id="usertable"
                        >
                            <TableHead sx={{ fontWeight: "600" }}>
                                <StyledTableRow>
                                        <StyledTableCell onClick={() => handleSorting('serialNumber')}><Box sx={userStyle.tableheadstyle}><Box>SNo</Box><Box sx={{marginTop:'-6PX'}}>{renderSortingIcon('serialNumber')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('expectcompdate')}><Box sx={userStyle.tableheadstyle}><Box>Estimation Time</Box><Box sx={{marginTop:'-6PX'}}>{renderSortingIcon('estimateTime')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('expectcomptime')}><Box sx={userStyle.tableheadstyle}><Box>Estimation Time</Box><Box sx={{marginTop:'-6PX'}}>{renderSortingIcon('estimateTime')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('expectcompduration')}><Box sx={userStyle.tableheadstyle}><Box>Estimation Time</Box><Box sx={{marginTop:'-6PX'}}>{renderSortingIcon('estimateTime')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('budget')}><Box sx={userStyle.tableheadstyle}><Box>Estimation Time</Box><Box sx={{marginTop:'-6PX'}}>{renderSortingIcon('estimateTime')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('budgetsign')}><Box sx={userStyle.tableheadstyle}><Box>Estimation Time</Box><Box sx={{marginTop:'-6PX'}}>{renderSortingIcon('estimateTime')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('priority')}><Box sx={userStyle.tableheadstyle}><Box>Project Name</Box><Box sx={{marginTop:'-6PX'}}>{renderSortingIcon('name')}</Box></Box></StyledTableCell>
                                        <StyledTableCell>Action</StyledTableCell>
                                        </StyledTableRow>
                                    </TableHead>
                                    <TableBody align="left">
                                    {filteredData.length > 0 ? (
                                    filteredData?.map((row, index) => (
                                            <StyledTableRow key={index}>
                                        <StyledTableCell align="left">{row.serialNumber}</StyledTableCell>
                                        <StyledTableCell align="left">{row.expectcompdate}</StyledTableCell>
                                        <StyledTableCell align="left">{row.expectcomptime}</StyledTableCell>
                                        <StyledTableCell align="left">{row.expectcompduration}</StyledTableCell>
                                        <StyledTableCell align="left">{row.budget}</StyledTableCell>
                                        <StyledTableCell align="left">{row.budgetsign}</StyledTableCell>
                                        <StyledTableCell align="left">{row.priority}</StyledTableCell>
                                        <StyledTableCell component="th" scope="row">
                                            <Grid sx={{ display: "flex" }}>
                                                <Button
                                                    sx={userStyle.buttonedit}
                                                    onClick={() => {
                                                        handleClickOpenEdit();
                                                        getCode(row._id);
                                                    }}
                                                >
                                                    <EditOutlinedIcon style={{ fontsize: "large" }} />
                                                </Button>
                                                <Button
                                                    sx={userStyle.buttondelete}
                                                    onClick={(e) => {
                                                        handleClickOpen();
                                                        rowData(row._id);
                                                    }}
                                                >
                                                    <DeleteOutlineOutlinedIcon
                                                        style={{ fontSize: "large" }}
                                                    />
                                                </Button>
                                                <Button
                                                    sx={userStyle.buttonedit}
                                                    onClick={() => {
                                                        handleClickOpenview();
                                                        getviewCode(row._id);
                                                    }}
                                                    >
                                                <VisibilityOutlinedIcon style={{ fontsize: "large" }} />
                                                </Button>
                                            </Grid>
                                        </StyledTableCell>
                                            </StyledTableRow>
                                         )))  :   <StyledTableRow> <StyledTableCell colSpan={4} align="center">No Data Available</StyledTableCell> </StyledTableRow> }
                                         </TableBody>
                                       </Table>
                                     </TableContainer>
                                     <Box style={userStyle.dataTablestyle}>
                                       <Box>
                                           Showing {((page - 1) * pageSize) + 1} to {Math.min(page * pageSize, projEstlist.length)} of {projEstlist.length} entries
                                         </Box>
                                         <Box>
                                           <Button onClick={() => handlePageChange(page - 1)} disabled={page === 1} sx={{textTransform:'capitalize',color:'black'}}>
                                             Prev
                                           </Button>
                                           {pageNumbers?.map((pageNumber) => (
                                             <Button key={pageNumber} sx={userStyle.paginationbtn} onClick={() => handlePageChange(pageNumber)} className={((page )) === pageNumber ? 'active' : ''} disabled={page === pageNumber}>
                                               {pageNumber}
                                             </Button>
                                           ))}
                                           {lastVisiblePage < totalPages && <span>...</span>}
                                           <Button onClick={() => handlePageChange(page + 1)} disabled={page === totalPages} sx={{textTransform:'capitalize',color:'black'}}>
                                             Next
                                           </Button>
                                         </Box>  
                                       </Box>       
                    {/* ****** Table End ****** */}

            
                </Box>
            </>
            {/* ****** Table End ****** */}

            {/* Delete Modal */}
            <Box>
                {/* ALERT DIALOG */}
                <Dialog
                    open={isDeleteOpen}
                    onClose={handleCloseMod}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogContent
                        sx={{ width: "350px", textAlign: "center", alignItems: "center" }}
                    >
                        <ErrorOutlineOutlinedIcon
                            sx={{ fontSize: "80px", color: "orange" }}
                        />
                        <Typography variant="h5" sx={{ color: "red", textAlign: "center" }}>
                            Are you sure?
                        </Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseMod} sx={userStyle.btncancel}>
                            Cancel
                        </Button>
                        <Button
                            autoFocus
                            variant="contained"
                            color="error"
                            onClick={(e) => delBranch(branchid)}
                        >
                            {" "}
                            OK{" "}
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>
            
      {/* view model */}
        <Dialog
          open={openview}
          onClose={handleClickOpenview}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
           <Box sx={userStyle.container}>
                            <Typography sx={userStyle.SubHeaderText}>Project Estimation </Typography>
                            <br/><br />
                            <>
                            <Grid container spacing={2}>
                                <Grid item md={6} xs={12} sm={12} >
                                        <FormControl fullWidth size="small">
                                            <Typography variant="h6"> Project</Typography>
                                            <Typography>{projEstimateEdit.project}</Typography>                    
                                        </FormControl>
                                </Grid>
                                <Grid item md={6} xs={12} sm={12} >
                                        <FormControl fullWidth size="small">
                                            <Typography variant="h6"> Sub-Project</Typography>
                                            <Typography>{projEstimateEdit.subproject}</Typography>                    
                                        </FormControl>
                                </Grid>
                    </Grid><br/>


                    <Grid container spacing={2}>
                        <Grid item md={6} sx={12}>
                                <Typography variant="h6"> Module</Typography>
                                <Typography>{projEstimateEdit.module}</Typography> 
                        </Grid>

                        <Grid item md={6} sx={12}>
                            <Typography variant="h6">Sub-Module</Typography>
                            <Typography>{projEstimateEdit.submodule}</Typography> 
                        </Grid>                    
                    </Grid><br/>

                    <Grid container spacing={2}>
                        <Grid item md={6} sx={12}>
                            <Typography variant="h6">Main Page</Typography>
                            <Typography>{projEstimateEdit.mainpage}</Typography> 
                        </Grid>
                        <Grid item md={6} sx={12}>
                            <Typography variant="h6">Sub-Page 1</Typography>
                            <Typography>{projEstimateEdit.subpage1}</Typography> 
                        </Grid>
                        <Grid item md={6} sx={12}>
                            <Typography variant="h6">Sub-Page 2</Typography>
                            <Typography>{projEstimateEdit.subpage2}</Typography>
                        </Grid>          
                    </Grid><br/>

                    
                    <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                            <Typography variant="h6">Expected Completion</Typography>
                            <Typography>{projEstimateEdit.expectcompdate}</Typography>
                        </Grid>
                        <Grid item md={4} sx={12}>
                            <Typography variant="h6">Expected Time</Typography>
                            <Typography>{projEstimateEdit.expectcomptime}</Typography>
                        </Grid>
                        <Grid item md={4} sx={12}>
                            <Typography variant="h6">Expected Duration</Typography>
                            <Typography>{projEstimateEdit.expectcompduration}</Typography>
                        </Grid>
                    </Grid><br/>

                    <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                            <Typography variant="h6">Budget</Typography>
                            <Typography>{projEstimateEdit.budget}</Typography>
                        </Grid>
                        <Grid item md={2} sx={12}>
                        <Typography  variant="h6">Budget</Typography>
                                 <Typography>{projEstimateEdit.budgetsign}</Typography>
                        </Grid>
                    </Grid>
                    <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                            <Typography variant="h6">priority</Typography>
                            <Typography>{projEstimateEdit.priority}</Typography>
                        </Grid>
                    </Grid>
                    <br/><br/>
                </>
                                <br/><br />
                                    <Grid item md={5} sx={12}>
                                        <Button variant="contained"onClick={handleCloseview}> Back </Button>
                                    </Grid>
                                    <Grid item md={1} sx={12}></Grid>
                             
                                
                            </Box>
        </Dialog>

            {/* print layout */}

            <TableContainer component={Paper} sx={userStyle.printcls}>
                <Table sx={{ minWidth: 700, }} aria-label="customized table" id="usertable" ref={componentRef}>

                    <TableHead sx={{ fontWeight: "600" }}>
                        <TableRow>
                            <TableCell> S.NO</TableCell>
                            <TableCell>Name</TableCell>
                        </TableRow>
                    </TableHead>
                    {projEstlist &&
                        projEstlist.map((row, index) => (
                            <TableRow key={index}>
                                <TableCell align="left">{index+1}</TableCell>
                                <TableCell align="left">{row.qualiname}</TableCell>
                               
                            </TableRow>
                        ))}
                </Table>
            </TableContainer>
        </Box>
    );
}

export default ProjectEstimation;