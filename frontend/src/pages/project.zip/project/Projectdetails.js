import React, { useState, useEffect, useRef } from "react";
import {
    Box, Typography, OutlinedInput, FormControl, TableBody, TableRow,TableCell,Select, MenuItem, DialogContent, Grid, Dialog, DialogActions, Paper, Table, TableHead, TableContainer, Button,
} from "@mui/material";
import { userStyle } from "../../pageStyle";
import axios from "axios";
import { FaPrint, FaFilePdf, FaFileCsv, FaFileExcel } from "react-icons/fa";
import { BsFiletypeDocx } from "react-icons/bs";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import { ExportXL, ExportCSV } from "../../components/Export";
import { StyledTableRow, StyledTableCell } from "../../components/Table";
import { useReactToPrint } from "react-to-print";
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import jsPDF from "jspdf";
import 'jspdf-autotable';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import DeleteIcon from '@mui/icons-material/Delete';
import { createTheme } from "@mui/material/styles";
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import moment from 'moment-timezone';
// import Headtitle from "../../components/header/Headtitle";
import $ from "jquery";
// import { UserRoleAccessContext } from "../../context/Appcontext";
import { SERVICE } from "../../services/Baseservice";
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import ArrowDropUpOutlinedIcon from '@mui/icons-material/ArrowDropUpOutlined';
import ArrowDropDownOutlinedIcon from '@mui/icons-material/ArrowDropDownOutlined';
// import { AuthContext } from '../../context/Appcontext';
// import { useNavigate} from 'react-router-dom';


function ProjectDetails() {
    // const { isUserRoleCompare } = useContext(UserRoleAccessContext);
    // const { auth, setAuth } = useContext(AuthContext);
    const [deleteProjDetail, setDeleteProjDetail] = useState(false);
    const [getrowid, setRowGetid] = useState("");
    const [projDetailsEdit, setProjDetailsEdit] = useState({});
    const [projdetails, setProjDetails] = useState({
        projectid: "", project: "", subproject: "", module: "", submodule: "",
        mainpage: "", subpage1: "", subpage2: "", subpage3: "", subpage4: "",
        subpage5: "", projectname: "", projectimages: "",
        projectdescrip: [], projectsummary: "", files: "",
    });
    const [projDetailsList, setProjDetailsList] = useState([]);
    const [project, setProject] = useState([]);
    const [subProject, setSubProject] = useState([]);
    const [module, setModule] = useState([]);
    const [submodule, setSubmodule] = useState([]);
    const [mainpage, setMainpage] = useState([]);
    const [subpage1, setSubpage1] = useState([]);
    const [subpage2, setSubpage2] = useState([]);
    const [subpage3, setSubpage3] = useState([]);
    const [subpage4, setSubpage4] = useState([]);
    const [subpage5, setSubpage5] = useState([]);
    const [projectEdit, setProjectEdit] = useState([]);
    const [subProjectEdit, setSubProjectEdit] = useState([]);
    const [moduleEdit, setModuleEdit] = useState([]);
    const [submoduleEdit, setSubmoduleEdit] = useState([]);
    const [mainpageEdit, setMainpageEdit] = useState([]);
    const [subpage1Edit, setSubpage1Edit] = useState([]);
    const [subpage2Edit, setSubpage2Edit] = useState([]);
    const [subpage3Edit, setSubpage3Edit] = useState([]);
    const [subpage4Edit, setSubpage4Edit] = useState([]);
    const [subpage5Edit, setSubpage5Edit] = useState([]);
    const [entries, setEntries] = useState(1);
    const [pages, setPages] = useState(1);
    const [text, setText] = useState();
    const [textEdit, setTextEdit] = useState();
    const [textSumm, setTextSummary] = useState();
    const [textSummEdit, setTextSummaryEdit] = useState();

    //its a username added details
    const [username, setUsername] = useState("");
    const [areatid, setAreatid] = useState({ code: "", name: "", addedby: "", updateby: [] });
    //const [textEdit, setTextEdit] = useState();

    const handleChange = (value) => {
        setText(value);
        // setTextEdit(value)
    };
    const handleChangeSummary = (value) => {
        setTextSummary(value);
        // setTextEdit(value)

    };
    const handleChangeSummaryEdit = (value) => {
        setTextSummaryEdit(value);
        // setTextEdit(value)

    };

    const handleChangeEdit = (value) => {
        setTextEdit(value);
        // setTextEdit(value)

    };
    //Datatable
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(1);
    
    // view model
    const [openview, setOpenview] = useState(false);
    // info model
    const [openInfo, setOpeninfo] = useState(false);
    const handleClickOpeninfo = () => {
        setOpeninfo(true);
    };
    const handleCloseinfo = () => {
        setOpeninfo(false);
    };

    const handleClickOpenview = () => {
        setOpenview(true);
    };

    const handleCloseview = () => {
        setOpenview(false);
    };


    //fetching Project for Dropdowns
    const fetchProjectDropdowns = async () => {
        try {
            let projectDrop = await axios.get(SERVICE.PROJECT);
            setProject(projectDrop.data.projects);
            setProjectEdit(projectDrop.data.projects);
        } catch (error) {
            console.log(error.response.data);
        }
    };

    //fetching sub-Project Dropdowns
    const fetchSubProjectDropdowns = async (e) => {
        try {
            let subPro = await axios.get(SERVICE.SUBPROJECT);
            let subProDrop = subPro.data.subprojects.filter((data) => {
                if (e === data.project)
                    return data
            })
            setSubProject(subProDrop);

        } catch (error) {
            console.log(error.response.data);
        }
    };



    
    //fetching Module Dropdowns
    const fetchModuleDropdowns = async (subPro) => {
        try {
            let dropModule = await axios.get(SERVICE.MODULE);
            let modulelist = dropModule.data.modules.filter((data) => {
                if (subPro === data.subproject) {
                    return data
                }

            })
            setModule(modulelist);
        } catch (error) {
            console.log(error.response.data);
        }
    };



    //fetching Sub-Modules Dropdowns
    const fetchSubModuleDropdowns = async (e) => {
        try {
            let drosubmod = await axios.get(SERVICE.SUBMODULE);
            let submodulelist = drosubmod.data.submodules.filter((data) => {
                if (e === data.module) {
                    return data
                }

            })
            setSubmodule(submodulelist);
        } catch (error) {
            console.log(error.response.data);
        }
    };


    //fetching Main Page Dropdowns
    const fetchMainPageDropdowns = async (e) => {
        try {
            let mainPag = await axios.get(SERVICE.MAINPAGE);
            let mainPagdrop = mainPag.data.mains.filter((data) => {
                if (e === data.submodule)
                    return data
            })
            setMainpage(mainPagdrop);
        } catch (error) {
            console.log(error.response.data);
        }
    };
   

    //fetching Sub-Page-1 Dropdowns
    const fetchSubPage1Dropdowns = async (e) => {
        try {
            let subpag1 = await axios.get(SERVICE.SUBPAGESONE);
            let subPag1Drop = subpag1.data.subpagesone.filter((data) => {
                if (e === data.mainpage)
                    return data
            })
            setSubpage1(subPag1Drop);
        } catch (error) {
            console.log(error.response.data);
        }
    };
    const [getmainpagename, setgetmainpagename] = useState("")

   


    //fetching Sub-Page-2 Dropdowns
    const fetchSubPage2Dropdowns = async (e) => {
        try {
            let subpag2 = await axios.get(SERVICE.SUBPAGESTWO);
            let subPag1Drop = subpag2.data.subpagestwo.filter((data) => {
                if (e === data.subpageone)
                    return data
            })

            setSubpage2(subPag1Drop);
        } catch (error) {
            console.log(error.response.data);
        }
    };
    
        //fetching Sub-Page-2 Dropdowns
        const fetchSubPage3Dropdowns = async (e) => {
            try {
                //console.log(e)
                let subpag2 = await axios.get(SERVICE.SUBPAGESTHREE);
                let subPag1Drop = subpag2.data.subpagesthree.filter((data) => {
                    console.log(e === data.subpagetwo);
                    if (e === data.subpagetwo)
                        return data
                })
    
                setSubpage3(subPag1Drop);
            } catch (error) {
                console.log(error.response.data);
            }
        };

        //fetching Sub-Page-4 Dropdowns
        const fetchSubPage4Dropdowns = async (subPage3) => {
            try {
                let subpag1 = await axios.get(SERVICE.SUBPAGESFOUR);
                let subPag1Drop = subpag1.data.subpagesfour.filter((data) => {
                    if (subPage3 === data.subpagethree)
                        return data
                })
                setSubpage4(subPag1Drop);
            } catch (error) {
                console.log(error.response.data);
            }
        };
       
           //fetching Sub-Page-4 Dropdowns
           const fetchSubPage5Dropdowns = async (subPage3) => {
            try {
                let subpag1 = await axios.get(SERVICE.SUBPAGESFIVE);
                let subPag1Drop = subpag1.data.subpagesfive.filter((data) => {
                    if (subPage3 === data.subpagefour)
                        return data
                })
                setSubpage5(subPag1Drop);
            } catch (error) {
                console.log(error.response.data);
            }
        };


    const [getprojectname, setgetprojectname] = useState("")

    //fetching sub-Project Dropdowns
    const fetchSubProjectDropdownsedit = async () => {
        let projectName = getprojectname ? getprojectname : projDetailsEdit.project;
        try {
            let subPro = await axios.get(SERVICE.SUBPROJECT);
            let subProDrop = subPro.data.subprojects.filter((data) => {
                if (projectName === data.project)
                    return data
            })
            setSubProjectEdit(subProDrop);

        } catch (error) {
            console.log(error.response.data);
        }
    };


    const [getsubprojectname, setgetsubprojectname] = useState("")

    //fetching Module Dropdowns
    const fetchModuleDropdownsedit = async () => {
        let subPro = getsubprojectname ? getsubprojectname : projDetailsEdit.subproject;

        try {
            let dropModule = await axios.get(SERVICE.MODULE);
            let modulelist = dropModule.data.modules.filter((data) => {
                if (subPro === data.subproject) {
                    return data
                }

            })
            setModuleEdit(modulelist);
        } catch (error) {
            console.log(error.response.data);
        }
    };


    const [getmodulename, setgetmodulename] = useState("")

    //fetching Sub-Modules Dropdowns
    const fetchSubModuleDropdownsedit = async () => {
        let modu = getmodulename ? getmodulename : projDetailsEdit.module;
        try {
            let drosubmod = await axios.get(SERVICE.SUBMODULE);
            let submodulelist = drosubmod.data.submodules.filter((data) => {
                if (modu === data.module) {
                    return data
                }

            })
            setSubmoduleEdit(submodulelist);
        } catch (error) {
            console.log(error.response.data);
        }
    };



    const [getsubmodulename, setgetsubmodulename] = useState("")

    //fetching Main Page Dropdowns
    const fetchMainPageDropdownsedit = async () => {
        let submod = getsubmodulename ? getsubmodulename : projDetailsEdit.submodule;

        try {
            let mainPag = await axios.get(SERVICE.MAINPAGE);
            let mainPagdrop = mainPag.data.mains.filter((data) => {
                if (submod === data.submodule)
                    return data
            })
            setMainpageEdit(mainPagdrop);
        } catch (error) {
            console.log(error.response.data);
        }
    };


     //fetching Sub-Page-1 Dropdowns
     const fetchSubPage1Dropdownsedit = async () => {
        let mainPag = getmainpagename ? getmainpagename : projDetailsEdit.mainpage;

        try {
            let subpag1 = await axios.get(SERVICE.SUBPAGESONE);
            let subPag1Drop = subpag1.data.subpagesone.filter((data) => {
                if (mainPag === data.mainpage)
                    return data
            })
            setSubpage1Edit(subPag1Drop);
        } catch (error) {
            console.log(error.response.data);
        }
    };


    const [getsubpage1name, setgetsubpage1name] = useState("")

    //fetching Sub-Page-2 Dropdowns
    const fetchSubPage2Dropdownsedit = async () => {
        let subpg1 = getsubpage1name ? getsubpage1name : projDetailsEdit.subpageone;

        try {
            let subpag2 = await axios.get(SERVICE.SUBPAGESTWO);
            let subPag1Drop = subpag2.data.subpagestwo.filter((data) => {
                if (subpg1 === data.subpageone)
                    return data
            })

            setSubpage2Edit(subPag1Drop);
        } catch (error) {
            console.log(error.response.data);
        }
    };

    //adding subpage3,4,5
       //fetching Sub-Page-3 Dropdowns

    const [getsubpage2name, setgetsubpage2name] = useState("")

    const fetchSubPage3Dropdownsedit = async () => {
        let subPage2 = getsubpage2name ? getsubpage2name : projDetailsEdit.subpagetwo;
        try {
            let subpag1 = await axios.get(SERVICE.SUBPAGESTHREE);
            let subPag1Drop = subpag1.data.subpagesthree.filter((data) => {
                if (subPage2 === data.subpagetwo)
                    return data
            })
            setSubpage3Edit(subPag1Drop);
        } catch (error) {
            console.log(error.response.data);
        }
    };

    const [getsubpage3name, setgetsubpage3name] = useState("")
    const fetchSubPage4Dropdownsedit = async () => {
        let subPage3 = getsubpage3name ? getsubpage3name : projDetailsEdit.subpagethree;

        try {
            let subpag1 = await axios.get(SERVICE.SUBPAGESFOUR);
            let subPag1Drop = subpag1.data.subpagesfour.filter((data) => {
                if (subPage3 === data.subpagethree)
                    return data
            })
            setSubpage4Edit(subPag1Drop);
        } catch (error) {
            console.log(error.response.data);
        }
    };

    const [getsubpage4name, setgetsubpage4name] = useState("")
           //fetching Sub-Page-5 Dropdowns
           const fetchSubPage5Dropdownsedit = async () => {
            try {
                let subPage4 = getsubpage4name ? getsubpage4name : projDetailsEdit.subpagefour;
                let subpag1 = await axios.get(SERVICE.SUBPAGESFIVE);
                let subPag1Drop = subpag1.data.subpagesfive.filter((data) => {
                    if (subPage4 === data.subpagefour)
                        return data
                })
                setSubpage5Edit(subPag1Drop);
            } catch (error) {
                console.log(error.response.data);
            }
        };



    //submitting the forms
    const handleSubmit = (e) => {
        e.preventDefault();
        sendRequest();
    };



    //submitting the form
    const sendRequest = async () => {
        try {
            let req = await axios.post(
                SERVICE.PROJECTDETAILS_CREATE,
                {
                    expectcompdate: String(projdetails.expectcompdate),
                    projectid: String(projdetails.projectid),
                    project: String(projdetails.project),
                    subproject: String(projdetails.subproject),
                    module: String(projdetails.module),
                    submodule: String(projdetails.submodule),
                    mainpage: String(projdetails.mainpage),
                    subpage1: String(projdetails.subpage1),
                    subpage2: String(projdetails.subpage2),
                    subpage3: String(projdetails.subpage3),
                    subpage4: String(projdetails.subpage4),
                    projectname: String(projdetails.projectname),
                    files: [...files],
                    projectdescrip: String(text),
                    projectsummary: String(textSumm),
                    addedby: [
                         {
                            name: String(username),
                            date: String(new Date()),
                        },
                    ],
                }
            );
            setProjDetails(req.data);
            setProjDetails({
                expectcompdate: "",
                projectid: "", project: "", subproject: "", module: "", submodule: "",
                mainpage: "", subpage1: "", subpage2: "", subpage3: "", subpage4: "",
                 projectname: "", projectimages: "", projectdescrip: "", projectsummary: "", files: ""
            });


        } catch (error) {
            console.log(error.response.data.errorMessage);
        }
    };

    //fetching Project Details for list Page
    const fetchProjDetailsList = async () => {
        try {
            let dep = await axios.get(SERVICE.PROJECTDETAILS);

            setProjDetailsList(dep.data.projectdetails);
        } catch (error) {
            console.log(error.response.data);
        }
    };


    //get single row to edit Page
    const getCode = async (e) => {
        setRowGetid(e);
        let res = await axios.get(
            `${SERVICE.PROJECTDETAILS_SINGLE}/${e}`,
            {}
        );

        setProjDetailsEdit(res.data.sprojectdetails);
        setFiles(res.data.sprojectdetails.files)
        setRowGetid(res.data.sprojectdetails);
    };

    // get single row to view....
    const getinfoCode = async (e) => {
        let res = await axios.get(`${SERVICE.PROJECTDETAILS_SINGLE}/${e}`, {});
        setProjDetailsEdit(res.data.sprojectdetails);
    };

    //Edit Button
    const editSubmit = (e) => {
        e.preventDefault();
        sendEditRequest();
    };


    //id for login...
    const [aid, setAid] = useState([]);
    let loginid = localStorage.LoginUserId;
    // console.log(localStorage);

    //get user row  edit  function
    const getusername = async () => {
        try {
            let res = await axios.get(`${SERVICE.USER}`)
            let user = res.data.users.filter((data) => {
                if (loginid === data._id) {
                    setUsername(data.username)
                    return data
                }
            })
            //setUsername(user)
        }
        catch (err) {
            console.log(err.response.data.errormessage)
        }
        // console.log(res.data.sarea)
    }

    let areasid = areatid._id;

    //updated by data added
    let updateby = projDetailsEdit.updatedby;
    let addedby = projDetailsEdit.addedby;


    //editing the single data for Edit Page
    let prod_det_id = getrowid._id;
    const sendEditRequest = async () => {
        try {
            let res = await axios.put(
                `${SERVICE.PROJECTDETAILS_SINGLE}/${prod_det_id}`,
                {
                    expectcompdate: String(projDetailsEdit.expectcompdate),
                    projectid: String(projDetailsEdit.projectid),
                    project: String(projDetailsEdit.project),
                    subproject: String(projDetailsEdit.subproject),
                    module: String(projDetailsEdit.module),
                    submodule: String(projDetailsEdit.submodule),
                    mainpage: String(projDetailsEdit.mainpage),
                    subpage1: String(projDetailsEdit.subpage1),
                    subpage2: String(projDetailsEdit.subpage2),
                    subpage3: String(projDetailsEdit.subpage3),
                    subpage4: String(projDetailsEdit.subpage4),
                    projectname: String(projDetailsEdit.projectname),
                    projectimages: String(projDetailsEdit.projectimages),
                    projectdescrip: String(textEdit),
                    projectsummary: String(textSummEdit),
                    updatedby: [
                        ...updateby, {
                            name: String(username),
                            date: String(new Date()),
                        },
                    ],
                    files: [...files],
                }
            );
            setProjDetailsEdit(res.data);
            handleCloseModEdit();
        } catch (err) {
            console.log(err.response.data)
        }
    };

    // Delete model
    const [isDeleteOpen, setIsDeleteOpen] = useState(false);
    const handleClickOpen = () => {
        setIsDeleteOpen(true);
    };
    const handleCloseMod = () => {
        setIsDeleteOpen(false);
    };

    // Edit model
    const [isEditOpen, setIsEditOpen] = useState(false);
    const handleClickOpenEdit = () => {
        setIsEditOpen(true);
    };
    const handleCloseModEdit = (e, reason) => {
        if (reason && reason === "backdropClick")
            return;
        setIsEditOpen(false);
    };

    //set function to get particular row to Delete
    const rowData = async (id) => {
        try {
            let res = await axios.get(
                `${SERVICE.PROJECTDETAILS_SINGLE}/${id}`
            );
            setDeleteProjDetail(res.data.sprojectdetails);
        } catch (err) { }
    };

    // Alert delete popup
    let proj_detail_Id = deleteProjDetail._id;
    const deleteDetail = async () => {
        try {
            await axios.delete(`${SERVICE.PROJECTDETAILS_SINGLE}/${proj_detail_Id}`);
            handleCloseMod();
        } catch (err) {
            console.log(err.response.data.errorMessage)
        }
    };

    // get single row to view page....
    const getviewCode = async (e) => {
        let res = await axios.get(`${SERVICE.PROJECTDETAILS_SINGLE}/${e}`, {});
        setProjDetailsEdit(res.data.sprojectdetails);
    };

    

    // Print
    const componentRef = useRef();
    const handleprint = useReactToPrint({
        content: () => componentRef.current,
        documentTitle: 'ProjectDetails',
        pageStyle: 'print'
    });
    
    const modifiedData = projDetailsList.map((person) => ({
        ...person,
        estimateTime: person.estimation + ' ' + person.estimationtime,
      }));

    //    PDF
    const columns = [
        { title: "Project ID", field: "projectid" },
        { title: "Project", field: "project" },
        { title: "Sub-Project", field: "subproject" },
        { title: "Module", field: "module" },
        { title: "Sub-Module", field: "submodule" },
        { title: "Main Page", field: "mainpage" },
        { title: "Sub-Page 1", field: "subpage1" },
        { title: "Sub-Page 2", field: "subpage2" },
        { title: "Sub-Page 3", field: "subpage3" },
        { title: "Sub-Page 4", field: "subpage4" },
        { title: "Task Name", field: "projectname" },
        // { title: "Description", field: "projectdescrip" },
        // { title: "Summary", field: "projectsummary" },
    ]
    const downloadPdf = () => {
        const doc = new jsPDF()
        doc.autoTable({
            theme: "grid",
            styles: {
                fontSize: 6,
              },
            columns: columns.map(col => ({ ...col, dataKey: col.field })),
            body: modifiedData
        })
        doc.save('ProjectDetails.pdf')
    }


    // Excel
    const fileName = "ProjectDetails";
    let excelno = 1;

    const [exceldata, setExceldata] = useState([]);

    // get perticular columns for export excel
    const getexcelDatas = async () => {


        var data = projDetailsList.map(t => ({
            SNo: excelno++,
            expectcompdate: t.expectcompdate,
            projectid: t.projectid,
            project: t.project,
            subproject: t.subproject,
            module: t.module,
            submodule: t.submodule,
            mainpage: t.mainpage,
            subpage1: t.subpage1,
            subpage2: t.subpage2,
            subpage3: t.subpage3,
            subpage4: t.subpage4,
            subpage5: t.subpage5,
            Taskname: t.projectname,
            // projectdescrip: <div dangerouslySetInnerHTML={{ __html: t.projectdescrip }}></div>,
            // projectsummary: <div dangerouslySetInnerHTML={{ __html: t.projectsummary }}></div>,

        }));
        setExceldata(data);
    }

  

    const [files, setFiles] = useState([]);


    const save = (data) => {
        // console.log(data);

    };
    const myTheme = createTheme({
        // Set up your custom MUI theme here
    });

    const handleFileUpload = (event) => {
        const files = event.target.files;
        const reader = new FileReader();
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            reader.readAsDataURL(file);
            reader.onload = () => {
                setFiles((prevFiles) => [
                    ...prevFiles,
                    { name: file.name, data: reader.result.split(',')[1] },
                ]);
            };
        }
    };

    const handleFileDelete = (index) => {
        setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index));
    };

    useEffect(() => {
        getexcelDatas();
        fetchProjectDropdowns();
        fetchSubProjectDropdownsedit();
        fetchModuleDropdowns();
        fetchModuleDropdownsedit();
        fetchSubModuleDropdownsedit();
        fetchMainPageDropdownsedit();
        fetchSubPage1Dropdownsedit();
        fetchSubPage2Dropdownsedit();
        fetchSubPage2Dropdowns();
        fetchSubProjectDropdowns();
        fetchSubPage3Dropdowns();
        fetchSubPage4Dropdowns();
        getusername();

    },[]);

    useEffect(() => {
        fetchProjDetailsList();
        fetchSubProjectDropdownsedit();
        fetchModuleDropdownsedit();
        fetchSubModuleDropdownsedit();
        fetchMainPageDropdownsedit();
        fetchSubPage1Dropdownsedit();
        fetchSubPage2Dropdownsedit();
        fetchSubPage3Dropdownsedit();
        fetchSubPage4Dropdownsedit();
        fetchSubPage5Dropdownsedit();
  

    });
    

    const [items, setItems] = useState([]);

    const addSerialNumber = () => {
    const itemsWithSerialNumber = modifiedData?.map((item, index) => ({ ...item, serialNumber: index + 1 }));
    setItems(itemsWithSerialNumber);
    }

    useEffect(()=>{
    addSerialNumber();
    })

    //table sorting
    const [sorting, setSorting] = useState({ column: '', direction: '' });

    const handleSorting = (column) => {
        const direction = sorting.column === column && sorting.direction === 'asc' ? 'desc' : 'asc';
        setSorting({ column, direction });
    };

    const sortedData = items.sort((a, b) => {
        if (sorting.direction === 'asc') {
            return a[sorting.column] > b[sorting.column] ? 1 : -1;
        } else if (sorting.direction === 'desc') {
            return a[sorting.column] < b[sorting.column] ? 1 : -1;
        }
        return 0;
    });

    const renderSortingIcon = (column) => {
        if (sorting.column !== column) {
            return <>
                <Box sx={{ color:'#bbb6b6'}}>
                    <Grid sx={{height:'6px',fontSize:'1.6rem'}}>
                        <ArrowDropUpOutlinedIcon/>
                    </Grid>
                    <Grid sx={{height:'6px',fontSize:'1.6rem'}}>
                        <ArrowDropDownOutlinedIcon/>
                    </Grid>
                </Box>
            </>;
        } else if (sorting.direction === 'asc') {
            return <>
                <Box >
                    <Grid sx={{height:'6px'}}>
                        <ArrowDropUpOutlinedIcon style={{ color:'black',fontSize:'1.6rem'}}/>
                    </Grid>
                    <Grid sx={{height:'6px'}}>
                        <ArrowDropDownOutlinedIcon style={{ color:'#bbb6b6',fontSize:'1.6rem'}}/>
                    </Grid>
                </Box>
            </>;
        } else {
            return  <>
                <Box >
                    <Grid sx={{height:'6px'}}>
                        <ArrowDropUpOutlinedIcon style={{ color:'#bbb6b6',fontSize:'1.6rem'}}/>
                    </Grid>
                    <Grid sx={{height:'6px'}}>
                        <ArrowDropDownOutlinedIcon style={{ color:'black',fontSize:'1.6rem'}}/>
                    </Grid>
                </Box>
            </>;
        }
    };
    //Datatable
    const handlePageChange = (newPage) => {
    setPage(newPage);
    };

    const handlePageSizeChange = (event) => {
    setPageSize(Number(event.target.value));
    setPage(1);
    };
    
    //datatable....
    const [searchQuery, setSearchQuery] = useState("");
    const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
    };
    const filteredDatas = items.filter((item) =>
    Object.values(item).some((value) =>
        value.toString().toLowerCase().includes(searchQuery.toLowerCase())
    )
    );

    const filteredData = filteredDatas.slice((page - 1) * pageSize, page * pageSize);

    const totalPages = Math.ceil(projDetailsList.length / pageSize);

    const visiblePages = Math.min(totalPages, 3);

    const firstVisiblePage = Math.max(1, page - 1);
    const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPages);

    const pageNumbers = [];

    const indexOfLastItem = page * pageSize;
    const indexOfFirstItem = indexOfLastItem - pageSize;

    for (let i = firstVisiblePage; i <= lastVisiblePage; i++) {
    pageNumbers.push(i);
    }



    return (
        <Box>
            {/* ****** Header Content ****** */}
            <Typography sx={userStyle.HeaderText}>Project Details</Typography>
            <form onSubmit={handleSubmit}>

                <Box sx={userStyle.container}>
                    <>
                        <Grid container spacing={2}>
                            <Grid item md={6} sx={12}>
                                <Typography>Project ID</Typography>

                                <FormControl fullWidth size="small">
                                    <OutlinedInput
                                        id="component-outlined"
                                        type="text"
                                        value={projdetails.projectid}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, projectid: e.target.value });
                                        }}
                                    />
                                </FormControl>
                            </Grid>
                        </Grid>
                        <Grid container spacing={2}>
                            <Grid item md={6} sx={12}>
                                <Typography>Project</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.project}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, project: e.target.value });
                                            fetchSubProjectDropdowns(e.target.value);
                                        }}
                                    >
                                        {
                                            project && project.map((data) => {
                                                return <MenuItem value={data.name}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item md={6} sx={12}>
                                <Typography>Sub-Project</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.subproject}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, subproject: e.target.value });
                                            fetchModuleDropdowns(e.target.value);
                                        }}
                                    >
                                        {
                                            subProject && subProject.map((data) => {
                                                return <MenuItem value={data.name}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>

                        </Grid><br />
                        <Grid container spacing={2}>
                            <Grid item md={6} sx={12}>
                                <Typography>Module</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.module}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, module: e.target.value });
                                            fetchSubModuleDropdowns(e.target.value);
                                        }}
                                    >
                                        {
                                            module && module.map((data) => {
                                                return <MenuItem value={data.name}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item md={6} sx={12}>
                                <Typography>Sub-Module</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.submodule}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, submodule: e.target.value });
                                            fetchMainPageDropdowns(e.target.value);

                                        }}
                                    >
                                        {
                                            submodule && submodule.map((data) => {
                                                return <MenuItem value={data.name}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>

                        </Grid><br />
                        <Grid container spacing={2}>
                            <Grid item md={4} sx={12}>
                                <Typography>Main Page</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.mainpage}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, mainpage: e.target.value });
                                            fetchSubPage1Dropdowns(e.target.value);
                                        }}
                                    >
                                        {
                                            mainpage && mainpage.map((data) => {
                                                return <MenuItem value={data.name}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} sx={12}>
                                <Typography>Sub-Page 1</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.subpage1}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, subpage1: e.target.value });
                                            fetchSubPage2Dropdowns(e.target.value);
                                        }}
                                    >
                                        {
                                            subpage1 && subpage1.map((data, index) => {
                                                return <MenuItem value={data.name} key={index}>{data.name}</MenuItem>
                                            })
                                        } 
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} sx={12}>
                                <Typography>Sub-Page 2</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.subpage2}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, subpage2: e.target.value });
                                            fetchSubPage3Dropdowns(e.target.value);
                                        }}
                                    >
                                        {
                                            subpage2 && subpage2.map((data, index) => {
                                                return <MenuItem value={data.name} key={index}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>

                        </Grid><br />
                        <Grid container spacing={2}>
                        <Grid item md={4} sx={12}>
                                <Typography>Sub-Page 3</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.subpage3}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, subpage3: e.target.value });
                                            fetchSubPage4Dropdowns(e.target.value);
                                        }}
                                    >
                                        {
                                            subpage3 && subpage3.map((data, index) => {
                                                return <MenuItem value={data.name} key={index}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} sx={12}>
                                <Typography>Sub-Page 4</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.subpage4}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, subpage4: e.target.value });
                                            fetchSubPage5Dropdowns(e.target.value);
                                        }}
                                    >
                                        {
                                            subpage4 && subpage4.map((data, index) => {
                                                return <MenuItem value={data.name} key={index}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} sx={12}>
                                <Typography>Sub-Page 5</Typography>

                                <FormControl fullWidth size="small">
                                    <Select
                                        labelId="demo-select-small"
                                        id="demo-select-small"
                                        value={projdetails.subpage5}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, subpage5: e.target.value });
                                        }}
                                    >
                                        {
                                            subpage5 && subpage5.map((data, index) => {
                                                return <MenuItem value={data.name} key={index}>{data.name}</MenuItem>
                                            })
                                        }
                                    </Select>
                                </FormControl>
                            </Grid>
                            </Grid>
                        <Grid container spacing={2}>
                            <Grid item md={6} sx={12}>
                                <Typography>Project Name</Typography>

                                <FormControl fullWidth size="small">
                                    <OutlinedInput
                                        id="component-outlined"
                                        type="text"
                                        value={projdetails.projectname}
                                        onChange={(e) => {
                                            setProjDetails({ ...projdetails, projectname: e.target.value });
                                        }}
                                    />
                                </FormControl>
                            </Grid>
                        </Grid><br />

                        <Grid item xs={8}>
                            <Typography sx={userStyle.SubHeaderText}>Document</Typography>
                        </Grid>
                        <>
                            <Grid container sx={{ justifyContent: "center" }} spacing={1}>
                                <Button variant="outlined" component="label">
                                    <CloudUploadIcon sx={{ fontSize: "21px" }} /> &ensp;Upload Documents
                                    <input hidden type="file" multiple onChange={handleFileUpload} />
                                </Button>
                            </Grid><br /><br /><br />
                        </>

                        <Grid container spacing={1}>

                            {files &&
                                (files.map((file, index) => (
                                    <>
                                        <Typography><a style={{ color: "#357ae8" }}
                                            href={`data:application/octet-stream;base64,${file.data}`}
                                            download={file.name}
                                        >
                                            {((file.name).split(".")[1] === "pdf") ? <FaFilePdf style={{ fontSize: "100px" }} /> :
                                                ((file.name).split(".")[1] === "csv") ? <FaFileCsv style={{ fontSize: "100px" }} /> :
                                                    ((file.name).split(".")[1] === "xlsx") ? <FaFileExcel style={{ fontSize: "100px" }} /> :
                                                        ((file.name).split(".")[1] === "docx") ? <BsFiletypeDocx style={{ fontSize: "100px" }} /> :
                                                            <img src={`data:application/octet-stream;base64,${file.data}`} style={{ width: '100px', height: '100px' }} />}
                                        </a></Typography> <br></br>
                                        <Typography><Button onClick={() => handleFileDelete(index)} size="small" ><DeleteIcon /></Button>  </Typography>
                                    </>
                                )))}
                        </Grid>
                        <br />
                        <Grid container spacing={2}>
                            <Grid item md={5} sx={12}>
                                <Typography>Description</Typography>
                                <ReactQuill
                                    value={text}
                                    onChange={handleChange}
                                    modules={{
                                        toolbar: [
                                            [{ 'header': '1' }, { 'header': '2' }, { 'font': [] }],
                                            [{ size: [] }],
                                            ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                                            [{ 'list': 'ordered' }, { 'list': 'bullet' },
                                            { 'indent': '-1' }, { 'indent': '+1' }],
                                            ['link', 'image', 'video'],
                                            ['clean']
                                        ]
                                    }}
                                    formats={[
                                        'header', 'font', 'size',
                                        'bold', 'italic', 'underline', 'strike', 'blockquote',
                                        'list', 'bullet', 'indent',
                                        'link', 'image', 'video'
                                    ]}
                                />
                            </Grid>
                            <Grid item md={1} sx={12}> </Grid>
                            <Grid item md={5} sx={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>Summary</Typography>
                                    <ReactQuill
                                        value={textSumm}
                                        onChange={handleChangeSummary}
                                        modules={{
                                            toolbar: [
                                                [{ 'header': '1' }, { 'header': '2' }, { 'font': [] }],
                                                [{ size: [] }],
                                                ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                                                [{ 'list': 'ordered' }, { 'list': 'bullet' },
                                                { 'indent': '-1' }, { 'indent': '+1' }],
                                                ['link', 'image', 'video'],
                                                ['clean']
                                            ]
                                        }}
                                        formats={[
                                            'header', 'font', 'size',
                                            'bold', 'italic', 'underline', 'strike', 'blockquote',
                                            'list', 'bullet', 'indent',
                                            'link', 'image', 'video'
                                        ]}
                                    />

                                </FormControl>
                            </Grid>
                        </Grid>
                        <br /><br />
                        <Grid item md={3} sx={12}>
                            <Button variant="contained" type="Submit">Create</Button>
                        </Grid>

                        <br />
                        <br />
                    </>

                    <>
                        <Box>
                            {/* ALERT DIALOG */}
                            <Dialog
                                open={isEditOpen}
                                onClose={handleCloseModEdit}
                                aria-labelledby="alert-dialog-title"
                                aria-describedby="alert-dialog-description"
                                maxWidth="lg"
                            >
                                <Box sx={userStyle.dialogbox}>
                                    <Typography sx={userStyle.SubHeaderText}> Edit Project Details </Typography>
                                    <br /><br />
                                    <>
                                        <Box>

                                            <Grid container spacing={1}>
                                                <Grid item md={6} sx={12}>
                                                    <Typography>Project ID</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <OutlinedInput
                                                            id="component-outlined"
                                                            type="text"
                                                            value={projDetailsEdit.projectid}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, projectid: e.target.value });
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                            </Grid>
                                            <Grid container spacing={2}>
                                                <Grid item md={6} sx={12}>
                                                    <Typography>Project</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.project}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, project: e.target.value });
                                                                setgetprojectname(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                projectEdit && projectEdit.map((data, index) => {
                                                                    return <MenuItem value={data.name} key={index}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={6} sx={12}>
                                                    <Typography>Sub-Project</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.subproject}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, subproject: e.target.value });
                                                                setgetsubprojectname(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                subProjectEdit && subProjectEdit.map((data) => {
                                                                    return <MenuItem value={data.name}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>

                                            </Grid><br />
                                            <Grid container spacing={2}>
                                                <Grid item md={6} sx={12}>
                                                    <Typography>Module</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.module}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, module: e.target.value });
                                                                setgetmodulename(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                moduleEdit && moduleEdit.map((data) => {
                                                                    return <MenuItem value={data.name}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={6} sx={12}>
                                                    <Typography>Sub-Module</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.submodule}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, submodule: e.target.value });
                                                                setgetsubmodulename(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                submoduleEdit && submoduleEdit.map((data) => {
                                                                    return <MenuItem value={data.name}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>

                                            </Grid><br />
                                            <Grid container spacing={2}>
                                                <Grid item md={4} sx={12}>
                                                    <Typography>Main Page</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.mainpage}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, mainpage: e.target.value });
                                                                setgetmainpagename(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                mainpageEdit && mainpageEdit.map((data) => {
                                                                    return <MenuItem value={data.name}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={4} sx={12}>
                                                    <Typography>Sub-Page 1</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.subpage1}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, subpage1: e.target.value });
                                                                setgetsubpage1name(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                subpage1Edit && subpage1Edit.map((data) => {
                                                                    return <MenuItem value={data.name}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={4} sx={12}>
                                                    <Typography>Sub-Page 2</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.subpage2}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, subpage2: e.target.value });
                                                                setgetsubpage2name(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                subpage2Edit && subpage2Edit.map((data, index) => {
                                                                    return <MenuItem value={data.name} key={index}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>

                                            </Grid><br />
                                            <Grid container spacing={2}>
                                                <Grid item md={4} sx={12}>
                                                <Typography>Sub-Page 3</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.subpage3}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, subpage3: e.target.value });
                                                                setgetsubpage3name(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                subpage3Edit && subpage3Edit.map((data) => {
                                                                    return <MenuItem value={data.name}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={4} sx={12}>
                                                    <Typography>Sub-Page 4</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.subpage4}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, subpage4: e.target.value });
                                                                setgetsubpage4name(e.target.value);
                                                            }}
                                                        >
                                                            {
                                                                subpage4Edit && subpage4Edit.map((data) => {
                                                                    return <MenuItem value={data.name}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={4} sx={12}>
                                                    <Typography>Sub-Page 5</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <Select
                                                            labelId="demo-select-small"
                                                            id="demo-select-small"
                                                            value={projDetailsEdit.subpage5}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, subpage5: e.target.value });
                                                            }}
                                                        >
                                                            {
                                                                subpage5Edit && subpage5Edit.map((data, index) => {
                                                                    return <MenuItem value={data.name} key={index}>{data.name}</MenuItem>
                                                                })
                                                            }
                                                        </Select>
                                                    </FormControl>
                                                </Grid>

                                            </Grid><br />
                                            <Grid container spacing={2}>
                                                <Grid item md={6} sx={12}>
                                                    <Typography>Project Name</Typography>

                                                    <FormControl fullWidth size="small">
                                                        <OutlinedInput
                                                            id="component-outlined"
                                                            type="text"
                                                            value={projDetailsEdit.projectname}
                                                            onChange={(e) => {
                                                                setProjDetailsEdit({ ...projDetailsEdit, projectname: e.target.value });
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                            </Grid><br /><br />
                                            <Grid item xs={8}>
                                                <Typography sx={userStyle.SubHeaderText}>Document</Typography><br></br>
                                            </Grid>
                                            <>
                                                <Grid container sx={{ justifyContent: "center" }} spacing={1}>
                                                    <Button variant="outlined" component="label">
                                                        <CloudUploadIcon sx={{ fontSize: "21px" }} /> &ensp;Upload Documents
                                                        <input hidden type="file" multiple onChange={handleFileUpload} />
                                                    </Button>
                                                </Grid><br /><br /><br />
                                            </>

                                            <Grid container spacing={1}>

                                                {files &&
                                                    (files.map((file, index) => (

                                                        <>

                                                            <Typography><a style={{ color: "#357ae8" }}
                                                                href={`data:application/octet-stream;base64,${file.data}`}
                                                                download={file.name}
                                                            >
                                                                {((file.name).split(".")[1] === "pdf") ? <FaFilePdf style={{ fontSize: "100px" }} /> :
                                                                    ((file.name).split(".")[1] === "csv") ? <FaFileCsv style={{ fontSize: "100px" }} /> :
                                                                        ((file.name).split(".")[1] === "xlsx") ? <FaFileExcel style={{ fontSize: "100px" }} /> :
                                                                            ((file.name).split(".")[1] === "docx" || "txt" || "doc") ? <BsFiletypeDocx style={{ fontSize: "100px" }} /> :

                                                                                <img src={`data:application/octet-stream;base64,${file.data}`} style={{ width: '100px', height: '100px' }} />}
                                                            </a></Typography> <br></br>
                                                            <Typography><Button onClick={() => handleFileDelete(index)} variant="contained" size="small" >Delete</Button> </Typography>
                                                        </>

                                                    )))}

                                            </Grid>

                                            <br />
                                            <Grid container spacing={2}>
                                                <Grid item md={5} sx={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>Description</Typography>
                                                        <ReactQuill
                                                            value={projDetailsEdit.projectdescrip}
                                                            onChange={handleChangeEdit}
                                                            modules={{
                                                                toolbar: [
                                                                    [{ 'header': '1' }, { 'header': '2' }, { 'font': [] }],
                                                                    [{ size: [] }],
                                                                    ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                                                                    [{ 'list': 'ordered' }, { 'list': 'bullet' },
                                                                    { 'indent': '-1' }, { 'indent': '+1' }],
                                                                    ['link', 'image', 'video'],
                                                                    ['clean']
                                                                ]
                                                            }}
                                                            formats={[
                                                                'header', 'font', 'size',
                                                                'bold', 'italic', 'underline', 'strike', 'blockquote',
                                                                'list', 'bullet', 'indent',
                                                                'link', 'image', 'video'
                                                            ]}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={1} sx={12}> </Grid>
                                                <Grid item md={5} sx={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>Summary</Typography>
                                                        <ReactQuill
                                                            value={projDetailsEdit.projectsummary}
                                                            onChange={handleChangeSummaryEdit}
                                                            modules={{
                                                                toolbar: [
                                                                    [{ 'header': '1' }, { 'header': '2' }, { 'font': [] }],
                                                                    [{ size: [] }],
                                                                    ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                                                                    [{ 'list': 'ordered' }, { 'list': 'bullet' },
                                                                    { 'indent': '-1' }, { 'indent': '+1' }],
                                                                    ['link', 'image', 'video'],
                                                                    ['clean']
                                                                ]
                                                            }}
                                                            formats={[
                                                                'header', 'font', 'size',
                                                                'bold', 'italic', 'underline', 'strike', 'blockquote',
                                                                'list', 'bullet', 'indent',
                                                                'link', 'image', 'video'
                                                            ]}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                            </Grid>
                                            <br /><br />
                                        </Box>
                                    </>
                                    <br /><br />
                                    <Grid container>
                                        <Grid item md={1} sx={12}></Grid>
                                        <Grid item md={5} sx={12}>
                                            <Button variant="contained" onClick={editSubmit}> Update </Button>
                                        </Grid>
                                        <Grid item md={5} sx={12}>
                                            <Button sx={userStyle.btncancel} onClick={handleCloseModEdit}> cancel </Button>
                                        </Grid>
                                        <Grid item md={1} sx={12}></Grid>
                                    </Grid>


                                </Box>
                            </Dialog>
                        </Box>
                    </>
                </Box>
            </form>

            <br />
            {/* ****** Table Start ****** */}
            <>
                <Box sx={userStyle.container}>
                    { /* ****** Header Buttons ****** */}
                    <Grid container sx={{ justifyContent: "center" }} >
                        <Grid >
                            {/* {isUserRoleCompare[0].excelsupplier && (
                                <> */}
                            <ExportCSV csvData={exceldata} fileName={fileName} />
                            {/* </>
                            )} */}
                            {/* {isUserRoleCompare[0].csvsupplier && (
                                <> */}
                            <ExportXL csvData={exceldata} fileName={fileName} />
                            {/* </>
                            )} */}
                            {/* {isUserRoleCompare[0].printsupplier && (
                                <> */}
                            <Button sx={userStyle.buttongrp} onClick={handleprint}>&ensp;<FaPrint />&ensp;Print&ensp;</Button>
                            {/* </>
                            )} */}
                            {/* {isUserRoleCompare[0].pdfsupplier && (
                                <> */}
                            <Button sx={userStyle.buttongrp} onClick={() => downloadPdf()}><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                            {/* </>
                            )} */}
                        </Grid>
                    </Grid><br />
                    {/* ****** Table Start ****** */}
                    <>

                        { /* ******************************************************EXPORT Buttons****************************************************** */}
                        {/* ****** Table Grid Container ****** */}
                        <Grid style={userStyle.dataTablestyle}>
                        <Box>
                            <label htmlFor="pageSizeSelect">Show entries:</label>
                            <Select id="pageSizeSelect" value={pageSize} onChange={handlePageSizeChange} sx={{width:"77px"}}>
                            <MenuItem value={1}>1</MenuItem>
                            <MenuItem value={5}>5</MenuItem>
                            <MenuItem value={10}>10</MenuItem>
                            <MenuItem value={25}>25</MenuItem>
                            <MenuItem value={50}>50</MenuItem>
                            <MenuItem value={100}>100</MenuItem>
                            <MenuItem value={(projDetailsList.length)}>All</MenuItem>
                            </Select>
                        </Box>
                        <Box>
                            <FormControl fullWidth size="small" >
                                <Typography>Search</Typography>
                                <OutlinedInput
                                    id="component-outlined"
                                    type="text"
                                    value={searchQuery}
                                    onChange={handleSearchChange}
                                />
                            </FormControl>
                        </Box>
                        </Grid>
                        {/* ****** Table start ****** */}
                        <TableContainer component={Paper}>
                            <Table
                               width="2000px"                         
                                aria-label="customized table"
                                id="usertable"
                            >
                                <TableHead sx={{ fontWeight: "600" }}>
                                    <StyledTableRow>
                                    <StyledTableCell onClick={() => handleSorting('serialNumber')}><Box sx={userStyle.tableheadstyle}><Box>Project ID</Box><Box>{renderSortingIcon('serialNumber')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('projectid')}><Box sx={userStyle.tableheadstyle}><Box>Project ID</Box><Box>{renderSortingIcon('projectid')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('project')}><Box sx={userStyle.tableheadstyle}><Box>Project</Box><Box>{renderSortingIcon('project')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('subproject')}><Box sx={userStyle.tableheadstyle}><Box>Sub-Project</Box><Box>{renderSortingIcon('subproject')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('module')}><Box sx={userStyle.tableheadstyle}><Box>Module</Box><Box>{renderSortingIcon('module')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('submodule')}><Box sx={userStyle.tableheadstyle}><Box>Sub-Module</Box><Box>{renderSortingIcon('submodule')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('mainpage')}><Box sx={userStyle.tableheadstyle}><Box>Main Page</Box><Box>{renderSortingIcon('mainpage')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('subpage1')}><Box sx={userStyle.tableheadstyle}><Box>Sub Page-1</Box><Box>{renderSortingIcon('subpage1')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('subpage2')}><Box sx={userStyle.tableheadstyle}><Box>Sub Page-2</Box><Box>{renderSortingIcon('subpage2')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('subpage3')}><Box sx={userStyle.tableheadstyle}><Box>Sub Page-2</Box><Box>{renderSortingIcon('subpage3')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('subpage4')}><Box sx={userStyle.tableheadstyle}><Box>Sub Page-2</Box><Box>{renderSortingIcon('subpage4')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('subpage5')}><Box sx={userStyle.tableheadstyle}><Box>Sub Page-2</Box><Box>{renderSortingIcon('subpage5')}</Box></Box></StyledTableCell> 
                                        <StyledTableCell onClick={() => handleSorting('projectname')}><Box sx={userStyle.tableheadstyle}><Box>Project Name</Box><Box>{renderSortingIcon('projectname')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('projectdescrip')}><Box sx={userStyle.tableheadstyle}><Box>Description</Box><Box>{renderSortingIcon('projectdescrip')}</Box></Box></StyledTableCell>
                                        <StyledTableCell onClick={() => handleSorting('projectsummary')}><Box sx={userStyle.tableheadstyle}><Box>Summary</Box><Box>{renderSortingIcon('projectsummary')}</Box></Box></StyledTableCell>
                                        <StyledTableCell>Actions</StyledTableCell>
                                    </StyledTableRow>
                                </TableHead>
                                <TableBody align="left">
                                {filteredData.length > 0 ? (
                                    filteredData?.map((row, index) => (
                                                <StyledTableRow key={index}>
                                                    <StyledTableCell align="left">{row.serialNumber}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.projectid}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.project}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.subproject}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.module}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.submodule}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.mainpage}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.subpage1}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.subpage2}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.subpage3}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.subpage4}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.subpage5}</StyledTableCell>
                                                    <StyledTableCell align="left">{row.projectname}</StyledTableCell>
                                                    <StyledTableCell align="left">{<div dangerouslySetInnerHTML={{ __html: row.projectdescrip }}></div>}</StyledTableCell>
                                                    <StyledTableCell align="left">{<div dangerouslySetInnerHTML={{ __html: row.projectsummary }}></div>}</StyledTableCell>
                                                    <StyledTableCell component="th" scope="row">
                                                        <Grid sx={{ display: "flex" }}>
                                                            <Button
                                                                sx={userStyle.buttonedit}
                                                                onClick={() => {
                                                                    handleClickOpenEdit();
                                                                    getCode(row._id);
                                                                }}
                                                            >
                                                                <EditOutlinedIcon style={{ fontsize: "large" }} />
                                                            </Button>
                                                            <Button
                                                                sx={userStyle.buttondelete}
                                                                onClick={(e) => {
                                                                    handleClickOpen();
                                                                    rowData(row._id);
                                                                }}
                                                            >
                                                                <DeleteOutlineOutlinedIcon
                                                                    style={{ fontSize: "large" }}
                                                                />
                                                            </Button>
                                                            <Button
                                                                sx={userStyle.buttonedit}
                                                                onClick={() => {
                                                                    handleClickOpenview();
                                                                    getviewCode(row._id);
                                                                }}
                                                            >
                                                                <VisibilityOutlinedIcon style={{ fontsize: "large" }} />
                                                            </Button>
                                                            <Button
                                                                sx={userStyle.buttonedit}
                                                                onClick={() => {
                                                                    handleClickOpeninfo();
                                                                    getinfoCode(row._id);
                                                                }}
                                                            >
                                                                <InfoOutlinedIcon style={{ fontsize: "large" }} />
                                                            </Button>

                                                        </Grid>
                                                    </StyledTableCell>
                                                </StyledTableRow>
                                           )))  :   <StyledTableRow> <StyledTableCell colSpan={16} align="center">No Data Available</StyledTableCell> </StyledTableRow> }
                                           </TableBody>
                                         </Table>
                                       </TableContainer>
                                       <Box style={userStyle.dataTablestyle}>
                                         <Box>
                                             Showing {((page - 1) * pageSize) + 1} to {Math.min(page * pageSize, projDetailsList.length)} of {projDetailsList.length} entries
                                           </Box>
                                           <Box>
                                             <Button onClick={() => handlePageChange(page - 1)} disabled={page === 1} sx={{textTransform:'capitalize',color:'black'}}>
                                               Prev
                                             </Button>
                                             {pageNumbers?.map((pageNumber) => (
                                               <Button key={pageNumber} sx={userStyle.paginationbtn} onClick={() => handlePageChange(pageNumber)} className={((page )) === pageNumber ? 'active' : ''} disabled={page === pageNumber}>
                                                 {pageNumber}
                                               </Button>
                                             ))}
                                             {lastVisiblePage < totalPages && <span>...</span>}
                                             <Button onClick={() => handlePageChange(page + 1)} disabled={page === totalPages} sx={{textTransform:'capitalize',color:'black'}}>
                                               Next
                                             </Button>
                                           </Box>  
                                         </Box> 
      
                        {/* ****** Table End ****** */}


                    </>
                    {/* ****** Table End ****** */}
                </Box>
            </>
            {/* ****** Table End ****** */}

            {/* Delete Modal */}
            <Box>
                {/* ALERT DIALOG */}
                <Dialog
                    open={isDeleteOpen}
                    onClose={handleCloseMod}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogContent
                        sx={{ width: "350px", textAlign: "center", alignItems: "center" }}
                    >
                        <ErrorOutlineOutlinedIcon
                            sx={{ fontSize: "80px", color: "orange" }}
                        />
                        <Typography variant="h5" sx={{ color: "red", textAlign: "center" }}>
                            Are you sure?
                        </Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseMod} sx={userStyle.btncancel}>
                            Cancel
                        </Button>
                        <Button
                            autoFocus
                            variant="contained"
                            color="error"
                            onClick={(e) => deleteDetail(proj_detail_Id)}
                        >
                            {" "}
                            OK{" "}
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>

            {/* view model */}
            <Dialog
                open={openview}
                onClose={handleClickOpenview}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth="md"
            >
                 <Box sx={{ width: '550px', padding: '20px 50px' }}>
                    <Box>
                    <Typography sx={userStyle.HeaderText}>View SubModule </Typography>
                        <br /><br />
                        <>
                            <Grid container spacing={2}>
                                <Grid item md={6} xs={12} sm={12}>
                                    <Typography variant="h6">Project ID</Typography>
                                    <Typography>{projDetailsEdit.projectid}</Typography>
                                </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Project</Typography>
                                <Typography>{projDetailsEdit.project}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Sub-Project</Typography>
                                <Typography>{projDetailsEdit.subproject}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Module</Typography>
                                <Typography>{projDetailsEdit.module}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6"> Sub-Module</Typography>
                                <Typography>{projDetailsEdit.submodule}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Main Page</Typography>
                                <Typography>{projDetailsEdit.mainpage}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Sub-Page 1</Typography>
                                <Typography>{projDetailsEdit.subpage1}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Sub-Page 2</Typography>
                                <Typography>{projDetailsEdit.subpage2}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Sub-Page 3</Typography>
                                <Typography>{projDetailsEdit.subpage3}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Sub-Page 4</Typography>
                                <Typography>{projDetailsEdit.subpage4}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Sub-Page 5</Typography>
                                <Typography>{projDetailsEdit.subpage5}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Project Name</Typography>
                                <Typography>{projDetailsEdit.projectname}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Description</Typography>
                                <Typography>{<div dangerouslySetInnerHTML={{ __html: projDetailsEdit.projectdescrip }}></div>}</Typography>
                            </Grid>
                            <Grid item md={6} xs={12} sm={12}>
                                <Typography variant="h6">Summary</Typography>
                                <Typography>{<div dangerouslySetInnerHTML={{ __html: projDetailsEdit.projectsummary }}></div>}</Typography>
                            </Grid>
                            </Grid>
                            <br/>
                        </>
                        <br/><br/>
                        <Grid container spacing={2}>
                            <Button variant="contained" onClick={handleCloseview}> Back </Button>
                        </Grid>
                        <Grid item md={1} sx={12}></Grid>

                    </Box>
                </Box>
            </Dialog>

            {/* this is info view details */}
           <Dialog
                open={openInfo}
                onClose={handleCloseinfo}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth="lg"
            >
                <Box sx={{ padding: '20px 50px' }}>
                    <>
                        <Typography sx={userStyle.HeaderText}> Info </Typography>
                        <br /><br />
                        <Grid container spacing={2}>
                            <Grid item md={12} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography variant="h6">addedby</Typography><br/>
                                    <Table>
                                        <TableHead>
                                            <StyledTableCell sx={{ padding: '5px 10px !important' }}>{"SNO"}.</StyledTableCell>
                                            <StyledTableCell sx={{ padding: '5px 10px !important' }}> {"UserName"}</StyledTableCell>
                                            <StyledTableCell sx={{ padding: '5px 10px !important' }}> {"Date"}</StyledTableCell>
                                        </TableHead>
                                        <TableBody>
                                            {addedby?.map((item, i) => (
                                                <StyledTableRow>
                                                    <StyledTableCell sx={{ padding: '5px 10px !important' }}>{i+1}.</StyledTableCell>
                                                    <StyledTableCell sx={{ padding: '5px 10px !important' }}> {item.name}</StyledTableCell>
                                                    <StyledTableCell sx={{ padding: '5px 10px !important' }}> {moment(item.date).format('DD-MM-YYYY hh:mm:ss a')}</StyledTableCell>
                                                </StyledTableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </FormControl>
                            </Grid>
                            <br />
                            <Grid item md={12} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography variant="h6">Updated by</Typography> <br />
                                    <Table>
                                        <TableHead>
                                            <StyledTableCell sx={{ padding: '5px 10px !important' }}>{"SNO"}.</StyledTableCell>
                                            <StyledTableCell sx={{ padding: '5px 10px !important' }}> {"UserName"}</StyledTableCell>
                                            <StyledTableCell sx={{ padding: '5px 10px !important' }}> {"Date"}</StyledTableCell>
                                        </TableHead>
                                        <TableBody>
                                            {updateby?.map((item, i) => (
                                                <StyledTableRow>
                                                    <StyledTableCell sx={{ padding: '5px 10px !important' }}>{i+1}.</StyledTableCell>
                                                    <StyledTableCell sx={{ padding: '5px 10px !important' }}> {item.name}</StyledTableCell>
                                                    <StyledTableCell sx={{ padding: '5px 10px !important' }}> {moment(item.date).format('DD-MM-YYYY hh:mm:ss a')}</StyledTableCell>
                                                </StyledTableRow>
                                            ))}
                                        </TableBody>
                                    </Table>

                                </FormControl>
                            </Grid>
                        </Grid>
                        <br /> <br /><br />
                        <Grid container spacing={2}>
                            <Button variant="contained" onClick={handleCloseinfo}> Back </Button>
                        </Grid>
                    </>
                </Box>
            </Dialog>

            {/* print layout */}

            <TableContainer component={Paper} sx={userStyle.printcls}>
                <Table sx={{ minWidth: 700, }} aria-label="customized table" id="usertable" ref={componentRef}>

                    <TableHead sx={{ fontWeight: "600" }}>
                        <TableRow>
                            <TableCell> S.NO</TableCell>
                            <TableCell>Project ID</TableCell>
                            <TableCell>Project</TableCell>
                            <TableCell>Sub-Project</TableCell>
                            <TableCell>Module</TableCell>
                            <TableCell>Sub-Module</TableCell>
                            <TableCell>Main Page</TableCell>
                            <TableCell>Sub-Page 1</TableCell>
                            <TableCell>Sub-Page 2</TableCell>
                            <TableCell>Project Name</TableCell>
                            <TableCell>Description</TableCell>
                            <TableCell>Summary</TableCell>
                        </TableRow>
                    </TableHead>
                    {projDetailsList &&
                        projDetailsList.map((row, index) => (
                            <TableRow key={index}>
                                <TableCell align="left">{index+1}</TableCell>
                                <TableCell align="left">{row.projectid}</TableCell>
                                <TableCell align="left">{row.project}</TableCell>
                                <TableCell align="left">{row.subproject}</TableCell>
                                <TableCell align="left">{row.module}</TableCell>
                                <TableCell align="left">{row.submodule}</TableCell>
                                <TableCell align="left">{row.mainpage}</TableCell>
                                <TableCell align="left">{row.subpage1}</TableCell>
                                <TableCell align="left">{row.subpage2}</TableCell>
                                <TableCell align="left">{row.projectname}</TableCell>
                                <TableCell align="left">{row.projectdescrip}</TableCell>
                                <TableCell align="left">{row.projectsummary}</TableCell>

                            </TableRow>
                        ))}
                </Table>
            </TableContainer>
        </Box>
    );
}

export default ProjectDetails;